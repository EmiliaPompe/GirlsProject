void sq(double *x, double *res) {
  *res = (*x) * (*x);
}
